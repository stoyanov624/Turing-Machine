#include <iostream>
#include "userInterface.h"
#include "tests.h"



int main() {
	//runTests();
	RUN();
}

